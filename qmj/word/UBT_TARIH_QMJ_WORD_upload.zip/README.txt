4 original Word files, unchanged bytes. Place each at the matching qmj/word/ path in GitHub zzhasau-web/ubttarih, branch main. Files are not converted.
